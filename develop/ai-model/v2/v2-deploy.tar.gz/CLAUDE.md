# AI Model v2 개발 가이드

## 프로젝트 개요

`ai-model/v2`는 `FastAPI + LangGraph` 기반 대화형 운동/식단 코칭 모델입니다.
현재 구조의 핵심은 아래 3가지입니다.

- `Draft -> Persona` 2단계 응답 생성
- `계획 제안 -> 사용자 승인 -> WAS 반영` 저장 흐름
- `selected_ai_persona` 기반 persona 시스템

## 현재 중요한 설계 원칙

### 1. Persona는 표현만 담당
- 사실, 근거, 경고, 계획 항목은 Draft가 결정합니다.
- Persona는 말투, 분위기, 세계관 표현만 바꿉니다.
- Persona가 새 근거를 만들면 안 됩니다.

### 2. Persona source of truth는 WAS
- 사용자 캐릭터 선택값은 `user_profile.selected_ai_persona`
- FastAPI는 이 값을 WAS에서 읽어 state에 반영합니다.
- 임시 request 단위 `ai_persona` override는 제거된 상태입니다.

### 3. Prompt는 코드 밖에서 관리
- node 시스템 지시사항: `app/prompts/nodes/`
- persona 프롬프트: `app/prompts/personas/`
- persona registry: `app/prompts/personas/registry.json`

### 4. 프로필 변경은 push event + next-turn refresh
- WAS가 내부 이벤트를 FastAPI로 push
- 다음 `/chat` 턴의 `preprocess`가 최신 프로필을 다시 읽음

## 디렉터리 안내

```text
v2/
├─ app/
│  ├─ main.py
│  ├─ core/
│  │  ├─ config.py
│  │  ├─ draft_contract.py
│  │  ├─ persona_registry.py
│  │  ├─ profile_sync.py
│  │  └─ prompt_loader.py
│  ├─ graph/
│  │  ├─ builder.py
│  │  ├─ deps.py
│  │  └─ nodes/
│  ├─ prompts/
│  │  ├─ nodes/
│  │  └─ personas/
│  ├─ routers/
│  │  ├─ chat.py
│  │  ├─ debug.py
│  │  └─ profile_events.py
│  └─ schemas/
├─ docs/
│  ├─ api_specification.md
│  ├─ profile_sync_flow.md
│  ├─ v2_model_analysis.md
│  └─ was_api_contract.md
```

## 먼저 읽으면 좋은 파일

1. `app/graph/builder.py`
2. `app/routers/chat.py`
3. `app/graph/nodes/preprocess.py`
4. `app/graph/nodes/intent.py`
5. `app/graph/nodes/search.py`
6. `app/graph/nodes/generate.py`
7. `app/graph/nodes/persona.py`

## 실행

```bash
uvicorn app.main:app --reload
```

## 디버그

- debug UI: `/debug`
- health check: `/health`
- internal event: `/internal/events/profile-updated`

## 참고 문서

- `docs/was_api_contract.md`
- `docs/api_specification.md`
- `docs/v2_model_analysis.md`
- `docs/profile_sync_flow.md`
- `docs/research_sources_and_tech_stack.md`
