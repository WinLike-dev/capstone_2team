from html import escape

from fastapi import APIRouter
from fastapi.responses import HTMLResponse

from app.core.persona_registry import list_active_personas

router = APIRouter(tags=["debug"])

EXAMPLE_MESSAGES: dict[str, list[tuple[str, str]]] = {
    "일상 / 캐주얼": [
        ("가벼운 대화", "오늘 운동하기 너무 귀찮아."),
        ("컨디션 체크", "오늘 컨디션이 애매한데 운동 가도 될까?"),
    ],
    "공감 케어": [
        ("의욕 저하", "요즘 운동 의욕이 너무 떨어져서 속상해."),
        ("식단 스트레스", "식단을 계속 실패해서 자꾸 자책하게 돼."),
    ],
    "기록 / 프로필": [
        ("체중 기록", "내 몸무게 71.8kg으로 기록해줘."),
        ("부상 이력", "무릎 통증이 있어서 부상 이력에 추가해줘."),
    ],
    "계획 생성": [
        ("운동 계획", "이번 주 주 4회 근비대 운동 계획 짜줘."),
        ("식단 계획", "감량용 하루 식단 계획 만들어줘."),
    ],
    "계획 수정": [
        ("일정 이동", "월요일 하체 운동을 수요일로 옮겨줘."),
        ("강도 조정", "이번 주 계획 강도를 조금 낮춰줘."),
    ],
    "계획 승인": [
        ("계획 승인", "좋아, 그 계획으로 진행해줘."),
        ("반영 요청", "오케이, 이대로 반영해줘."),
    ],
    "정보 검색": [
        ("단백질 질문", "감량 중에도 단백질을 많이 먹어야 해?"),
        ("HIIT 질문", "HIIT를 주 몇 회 정도 넣는 게 좋아?"),
    ],
    "안전 경고": [
        ("흉통", "운동하다가 가슴이 조여오고 숨이 차."),
        ("어지럼증", "러닝 중에 어지럽고 식은땀이 나."),
    ],
    "Fallback / 모호한 입력": [
        ("모호한 수정", "그거 좀 다르게 해줘."),
        ("맥락 의존", "아까 말한 거 기준으로 다시 해줘."),
    ],
}

html_template = """
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Hub v2 Debug Chat</title>
    <style>
        :root {
            --bg-color: #0b1020;
            --panel-bg: #151c31;
            --panel-soft: #1d2742;
            --text-color: #d2dae8;
            --text-strong: #f8fafc;
            --text-muted: #7c8aa5;
            --border-color: #30405f;
            --primary: #5b7cff;
            --primary-hover: #7690ff;
            --user-msg-bg: #3c4dd8;
            --bot-msg-bg: #172033;
            --accent: #22c55e;
            --danger: #ef4444;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            padding: 0;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #0b1020 0%, #0d1428 100%);
            color: var(--text-color);
            display: flex;
            height: 100vh;
            overflow: hidden;
        }

        .sidebar {
            width: 390px;
            background-color: var(--panel-bg);
            border-right: 1px solid var(--border-color);
            display: flex;
            flex-direction: column;
        }

        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid var(--border-color);
            background: rgba(91, 124, 255, 0.08);
        }

        .sidebar-header h1 {
            margin: 0;
            font-size: 1.05rem;
            color: var(--text-strong);
        }

        .sidebar-header p {
            margin: 8px 0 0 0;
            font-size: 0.8rem;
            color: var(--text-muted);
            line-height: 1.5;
        }

        .sidebar-content {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 18px;
        }

        .section {
            background: rgba(13, 20, 40, 0.55);
            border: 1px solid var(--border-color);
            border-radius: 14px;
            padding: 16px;
        }

        .section-title {
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: var(--text-muted);
            margin-bottom: 12px;
            font-weight: 700;
        }

        .input-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
            margin-bottom: 10px;
        }

        .input-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }

        .input-group label {
            font-size: 0.8rem;
            color: var(--text-color);
        }

        select, input, textarea {
            width: 100%;
            background-color: #0c1427;
            border: 1px solid var(--border-color);
            color: var(--text-strong);
            padding: 10px 12px;
            border-radius: 10px;
            font-size: 0.9rem;
            outline: none;
        }

        textarea {
            min-height: 70px;
            resize: vertical;
        }

        select:focus, input:focus, textarea:focus {
            border-color: var(--primary);
        }

        .hint {
            font-size: 0.75rem;
            color: var(--text-muted);
            line-height: 1.5;
        }

        .btn {
            padding: 10px 12px;
            border-radius: 10px;
            border: 1px solid transparent;
            cursor: pointer;
            font-weight: 600;
            font-size: 0.85rem;
            transition: all 0.2s;
        }

        .btn-row {
            display: flex;
            gap: 10px;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover { background: var(--primary-hover); }

        .btn-secondary {
            background: #0c1427;
            color: var(--text-color);
            border-color: var(--border-color);
        }

        .btn-secondary:hover {
            background: #13203a;
        }

        .btn-example {
            width: 100%;
            text-align: left;
            background: #13203a;
            color: var(--text-color);
            border-color: var(--border-color);
        }

        .btn-example:hover {
            border-color: var(--primary);
            background: #192a4b;
        }

        .example-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
            margin-bottom: 14px;
        }

        .example-group-title {
            font-size: 0.82rem;
            color: var(--text-strong);
            font-weight: 700;
        }

        .main-view {
            flex: 1;
            display: flex;
            flex-direction: column;
            background:
                radial-gradient(circle at top right, rgba(91, 124, 255, 0.12), transparent 28%),
                radial-gradient(circle at bottom left, rgba(34, 197, 94, 0.08), transparent 25%);
        }

        .chat-area {
            flex: 1;
            overflow-y: auto;
            padding: 32px;
            display: flex;
            flex-direction: column;
            gap: 22px;
        }

        .message-row {
            display: flex;
            flex-direction: column;
            gap: 8px;
            max-width: 82%;
        }

        .message-row.user {
            align-self: flex-end;
            align-items: flex-end;
        }

        .message-row.bot {
            align-self: flex-start;
            align-items: flex-start;
        }

        .bubble {
            padding: 16px 18px;
            border-radius: 18px;
            line-height: 1.65;
            font-size: 0.95rem;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.16);
        }

        .user .bubble {
            background-color: var(--user-msg-bg);
            color: white;
            border-bottom-right-radius: 6px;
        }

        .bot .bubble {
            background-color: var(--bot-msg-bg);
            color: var(--text-strong);
            border-bottom-left-radius: 6px;
            border: 1px solid var(--border-color);
        }

        .debug-info {
            width: 100%;
            border-radius: 12px;
            overflow: hidden;
            border: 1px solid var(--border-color);
            background: rgba(12, 20, 39, 0.75);
        }

        .debug-header {
            padding: 10px 14px;
            background: #1a2744;
            color: var(--primary);
            font-size: 0.76rem;
            font-weight: 700;
            display: flex;
            justify-content: space-between;
        }

        .debug-body {
            padding: 14px;
            font-family: 'JetBrains Mono', monospace;
            font-size: 0.79rem;
            color: #a5d8ff;
            white-space: pre-wrap;
            line-height: 1.6;
        }

        .draft-text {
            color: #fbbf24;
            margin-bottom: 12px;
            padding-bottom: 12px;
            border-bottom: 1px dashed var(--border-color);
        }

        .loader {
            display: none;
            text-align: center;
            color: var(--text-muted);
            font-size: 0.9rem;
            padding-bottom: 12px;
        }

        .input-bar {
            padding: 22px 28px;
            border-top: 1px solid var(--border-color);
            background: rgba(11, 16, 32, 0.8);
            backdrop-filter: blur(10px);
        }

        .input-container {
            max-width: 1040px;
            margin: 0 auto;
            display: flex;
            gap: 14px;
        }

        #msgInput {
            flex: 1;
            padding: 16px 20px;
            border-radius: 999px;
        }

        #btnSend {
            min-width: 108px;
            border-radius: 999px;
        }

        .muted-link {
            color: var(--primary);
            text-decoration: none;
            font-size: 0.8rem;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header">
            <h1>v2 Debug Chat</h1>
            <p>프로필 override, persona 테스트, 기능별 예제 문장으로 `/chat`을 빠르게 검증하는 내부 페이지입니다.</p>
        </div>

        <div class="sidebar-content">
            <div class="section">
                <div class="section-title">Session Control</div>
                <div class="input-group">
                    <label>User ID</label>
                    <input type="text" id="userId" value="dev_tester">
                </div>
                <div class="btn-row">
                    <button class="btn btn-secondary" id="btnReset" type="button">New Session</button>
                    <button class="btn btn-secondary" id="btnClearOverrides" type="button">Clear Overrides</button>
                </div>
            </div>

            <div class="section">
                <div class="section-title">Profile Overrides (Test Only)</div>
                <div class="input-group">
                    <label>Selected Persona</label>
                    <select id="personaSelect">
                        __PERSONA_OPTIONS__
                    </select>
                </div>
                <div class="input-group">
                    <label>MBTI</label>
                    <select id="mbtiSelect">
                        <option value="">(Default)</option>
                        <option value="ESTJ">ESTJ</option>
                        <option value="ESTP">ESTP</option>
                        <option value="ENTJ">ENTJ</option>
                        <option value="ENTP">ENTP</option>
                        <option value="ESFJ">ESFJ</option>
                        <option value="ESFP">ESFP</option>
                        <option value="ENFJ">ENFJ</option>
                        <option value="ENFP">ENFP</option>
                        <option value="ISTJ">ISTJ</option>
                        <option value="ISTP">ISTP</option>
                        <option value="INTJ">INTJ</option>
                        <option value="INTP">INTP</option>
                        <option value="ISFJ">ISFJ</option>
                        <option value="ISFP">ISFP</option>
                        <option value="INFJ">INFJ</option>
                        <option value="INFP">INFP</option>
                    </select>
                </div>
                <div class="input-group">
                    <label>Goal</label>
                    <select id="goalSelect">
                        <option value="">(Default)</option>
                        <option value="fat_loss">fat_loss</option>
                        <option value="muscle_gain">muscle_gain</option>
                        <option value="maintenance">maintenance</option>
                        <option value="health">health</option>
                    </select>
                </div>
                <div class="input-grid">
                    <div class="input-group">
                        <label>Activity Level</label>
                        <select id="activityLevelSelect">
                            <option value="">(Default)</option>
                            <option value="low">low</option>
                            <option value="moderate">moderate</option>
                            <option value="high">high</option>
                        </select>
                    </div>
                    <div class="input-group">
                        <label>Diet Type</label>
                        <select id="dietTypeSelect">
                            <option value="">(Default)</option>
                            <option value="balanced">balanced</option>
                            <option value="high_protein">high_protein</option>
                            <option value="vegetarian">vegetarian</option>
                            <option value="vegan">vegan</option>
                            <option value="low_carb">low_carb</option>
                        </select>
                    </div>
                </div>
                <div class="input-grid">
                    <div class="input-group">
                        <label>Gender</label>
                        <select id="genderSelect">
                            <option value="">(Default)</option>
                            <option value="male">male</option>
                            <option value="female">female</option>
                        </select>
                    </div>
                    <div class="input-group">
                        <label>Age</label>
                        <input type="number" id="ageInput" placeholder="25">
                    </div>
                </div>
                <div class="input-grid">
                    <div class="input-group">
                        <label>Weight (kg)</label>
                        <input type="number" step="0.1" id="weightInput" placeholder="72.5">
                    </div>
                    <div class="input-group">
                        <label>Height (cm)</label>
                        <input type="number" step="0.1" id="heightInput" placeholder="175">
                    </div>
                </div>
                <div class="input-group">
                    <label>Allergies (comma separated)</label>
                    <input type="text" id="allergiesInput" placeholder="milk, peanut">
                </div>
                <div class="input-group">
                    <label>Injury History (comma separated)</label>
                    <input type="text" id="injuryInput" placeholder="knee, shoulder">
                </div>
                <div class="hint">입력한 값만 이번 요청의 `user_profile_override`에 포함됩니다. 비워두면 WAS 프로필 또는 기본값이 사용됩니다.</div>
            </div>

            <div class="section">
                <div class="section-title">Test Examples</div>
                <div class="hint">기능별 버튼을 누르면 입력창에 예제 문장이 채워집니다.</div>
                <div style="margin-top:12px">
                    __EXAMPLE_SECTIONS__
                </div>
            </div>

            <div style="flex:1"></div>

            <div class="section">
                <a href="https://smith.langchain.com/" target="_blank" class="muted-link">Open LangSmith Dashboard</a>
            </div>
        </div>
    </div>

    <div class="main-view">
        <div class="chat-area" id="chatHistory">
            <div class="message-row bot">
                <div class="bubble">
                    v2 Debug Chat에 오신 것을 환영합니다.<br>
                    왼쪽에서 persona와 profile override를 바꾸고, 예제 문장으로 각 기능을 바로 테스트해보세요.
                </div>
            </div>
        </div>

        <div class="loader" id="loader">응답을 생성하는 중입니다...</div>

        <div class="input-bar">
            <form class="input-container" id="chatForm">
                <input type="text" id="msgInput" placeholder="테스트할 문장을 입력하세요..." autocomplete="off" required>
                <button type="submit" class="btn btn-primary" id="btnSend">Send</button>
            </form>
        </div>
    </div>

<script>
    function generateUUID() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
            const r = Math.random() * 16 | 0;
            const v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    let sessionId = generateUUID();
    const chatHistory = document.getElementById('chatHistory');
    const chatForm = document.getElementById('chatForm');
    const msgInput = document.getElementById('msgInput');
    const userIdEl = document.getElementById('userId');
    const loader = document.getElementById('loader');
    const personaSelect = document.getElementById('personaSelect');
    const mbtiSelect = document.getElementById('mbtiSelect');
    const goalSelect = document.getElementById('goalSelect');
    const activityLevelSelect = document.getElementById('activityLevelSelect');
    const dietTypeSelect = document.getElementById('dietTypeSelect');
    const genderSelect = document.getElementById('genderSelect');
    const ageInput = document.getElementById('ageInput');
    const weightInput = document.getElementById('weightInput');
    const heightInput = document.getElementById('heightInput');
    const allergiesInput = document.getElementById('allergiesInput');
    const injuryInput = document.getElementById('injuryInput');

    document.getElementById('btnReset').onclick = () => {
        sessionId = generateUUID();
        chatHistory.innerHTML += `<div style="text-align:center; color:var(--text-muted); font-size:0.8rem; margin:10px 0;">--- Session Reset [${sessionId}] ---</div>`;
    };

    document.getElementById('btnClearOverrides').onclick = () => {
        personaSelect.value = 'default';
        mbtiSelect.value = '';
        goalSelect.value = '';
        activityLevelSelect.value = '';
        dietTypeSelect.value = '';
        genderSelect.value = '';
        ageInput.value = '';
        weightInput.value = '';
        heightInput.value = '';
        allergiesInput.value = '';
        injuryInput.value = '';
    };

    document.querySelectorAll('[data-example-message]').forEach((button) => {
        button.addEventListener('click', () => {
            msgInput.value = button.dataset.exampleMessage || '';
            msgInput.focus();
        });
    });

    function appendMessage(text, sender, debug = null) {
        const row = document.createElement('div');
        row.className = `message-row ${sender}`;

        const bubble = document.createElement('div');
        bubble.className = 'bubble';
        bubble.innerHTML = text.replace(/\\n/g, '<br>');
        row.appendChild(bubble);

        if (debug && sender === 'bot') {
            const debugPanel = document.createElement('div');
            debugPanel.className = 'debug-info';
            debugPanel.innerHTML = `
                <div class="debug-header"><span>TRACE DATA</span><span>STATE SNAPSHOT</span></div>
                <div class="debug-body">
                    <div class="draft-text"><strong>[Draft Preview]</strong><br>${debug.draft || 'N/A'}</div>
                    <strong>[Debug State]</strong><br>${JSON.stringify(debug.state, null, 2)}
                </div>
            `;
            row.appendChild(debugPanel);
        }

        chatHistory.appendChild(row);
        chatHistory.scrollTop = chatHistory.scrollHeight;
    }

    function parseCsv(value) {
        return value
            .split(',')
            .map(item => item.trim())
            .filter(Boolean);
    }

    function parseNumber(value, integerOnly = false) {
        if (!value || !value.trim()) return null;
        const parsed = integerOnly ? Number.parseInt(value, 10) : Number.parseFloat(value);
        return Number.isNaN(parsed) ? null : parsed;
    }

    function buildUserProfileOverride() {
        const override = {};

        if (personaSelect.value && personaSelect.value !== 'default') {
            override.selected_ai_persona = personaSelect.value;
        }
        if (mbtiSelect.value) override.mbti = mbtiSelect.value;
        if (goalSelect.value) override.goal = goalSelect.value;
        if (activityLevelSelect.value) override.activity_level = activityLevelSelect.value;
        if (dietTypeSelect.value) override.diet_type = dietTypeSelect.value;
        if (genderSelect.value) override.gender = genderSelect.value;

        const age = parseNumber(ageInput.value, true);
        const weight = parseNumber(weightInput.value);
        const height = parseNumber(heightInput.value);
        const allergies = parseCsv(allergiesInput.value);
        const injuryHistory = parseCsv(injuryInput.value);

        if (age !== null) override.age = age;
        if (weight !== null) override.weight = weight;
        if (height !== null) override.height = height;
        if (allergies.length) override.allergies = allergies;
        if (injuryHistory.length) override.injury_history = injuryHistory;

        return override;
    }

    chatForm.onsubmit = async (e) => {
        e.preventDefault();
        const text = msgInput.value.trim();
        if (!text) return;

        msgInput.value = '';
        appendMessage(text, 'user');
        loader.style.display = 'block';

        const override = buildUserProfileOverride();

        try {
            const requestBody = {
                user_id: userIdEl.value,
                user_message: text,
                session_id: sessionId,
                ...(Object.keys(override).length ? { user_profile_override: override } : {})
            };

            const res = await fetch('/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(requestBody)
            });

            const data = await res.json();
            loader.style.display = 'none';

            if (res.ok) {
                appendMessage(data.response, 'bot', {
                    draft: data.draft_response,
                    state: data.debug_state
                });
            } else {
                appendMessage("Error: " + (data.error?.message || "Unknown"), 'bot');
            }
        } catch (err) {
            loader.style.display = 'none';
            appendMessage("API Error: " + err.message, 'bot');
        }
    };
</script>
</body>
</html>
"""


def _build_persona_options() -> str:
    options: list[str] = []
    for persona in list_active_personas():
        persona_id = escape(str(persona["id"]))
        prompt_file = escape(str(persona["prompt_file"]))
        label = escape(str(persona["label"]))
        selected = " selected" if bool(persona["is_default"]) else ""
        options.append(
            f'<option value="{persona_id}"{selected}>{label} ({prompt_file})</option>'
        )
    return "\n".join(options)


def _build_example_sections() -> str:
    sections: list[str] = []
    for group_name, examples in EXAMPLE_MESSAGES.items():
        buttons: list[str] = []
        for label, message in examples:
            buttons.append(
                f'<button class="btn btn-example" type="button" '
                f'data-example-message="{escape(message)}">{escape(label)}: {escape(message)}</button>'
            )
        sections.append(
            '<div class="example-group">'
            f'<div class="example-group-title">{escape(group_name)}</div>'
            + "".join(buttons)
            + '</div>'
        )
    return "\n".join(sections)


@router.get("/debug", response_class=HTMLResponse)
async def get_debug_page():
    return (
        html_template
        .replace("__PERSONA_OPTIONS__", _build_persona_options())
        .replace("__EXAMPLE_SECTIONS__", _build_example_sections())
    )
